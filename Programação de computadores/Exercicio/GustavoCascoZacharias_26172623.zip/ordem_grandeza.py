print("Digite um numero")
numero = int(input())

if((numero >= 0 ) and (numero < 100)):
    print (numero,"está entre 0 e 100")
if((numero >= 100 ) and (numero < 1000)):
    print (numero,"está entre 100 e 1000")
if(numero >= 1000 ):
    print (numero,"é maior ou igual a 1000")
if(numero < 0 ):
    print (numero,"esse numero é menor que zero")  
      


    

